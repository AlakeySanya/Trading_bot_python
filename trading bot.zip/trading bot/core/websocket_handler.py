from loguru import logger
import asyncio
import websockets
import json


class WebSocketHandler:
    def __init__(self):
        self.spot_task = None
        self.futures_task = None
        self.running = True
        logger.info("WebSocketHandler инициализирован")

    async def start(self, spot_tickers, futures_tickers, callback):
        self.running = True
        if spot_tickers:
            self.spot_task = asyncio.create_task(self.listen_spot(spot_tickers, callback))
        if futures_tickers:
            self.futures_task = asyncio.create_task(self.listen_futures(futures_tickers, callback))

    async def stop(self):
        self.running = False
        if self.spot_task:
            self.spot_task.cancel()
            logger.info("Остановлена подписка SPOT")
        if self.futures_task:
            self.futures_task.cancel()
            logger.info("Остановлена подписка FUTURES")

    async def listen_spot(self, tickers, callback):
        streams = '/'.join([
            f"{ticker.lower()}@kline_1m/{ticker.lower()}@depth20@100ms"
            for ticker in tickers
        ])
        url = f"wss://stream.binance.com:9443/stream?streams={streams}"
        logger.info(f"Подключение к SPOT WebSocket: {url}")

        websocket = await self.connect(url)
        try:
            async for message in websocket:
                data = json.loads(message)
                stream = data.get('stream', '')
                payload = data.get('data', {})

                ticker = stream.split('@')[0].upper()

                if '@kline' in stream:
                    kline = payload.get('k', {})
                    result = {
                        "ticker": ticker,
                        "open": float(kline["o"]),
                        "close": float(kline["c"]),
                        "high": float(kline["h"]),
                        "low": float(kline["l"]),
                        "volume": float(kline["v"]),
                        "is_closed": kline["x"],
                        "time_start": kline["t"],
                        "time_close": kline["T"],
                        "is_futures": False,
                        "type": "kline"
                    }
                    await callback(result)

                elif '@depth' in stream:
                    result = {
                        "ticker": ticker,
                        "bids": payload.get("b", []),
                        "asks": payload.get("a", []),
                        "is_futures": False,
                        "type": "depth"
                    }
                    await callback(result)

        except websockets.ConnectionClosed:
            logger.warning("Соединение SPOT WebSocket закрыто. Переподключение...")


    async def listen_futures(self, tickers, callback):
        streams = '/'.join([
            f"{ticker.lower()}@kline_1m/{ticker.lower()}@depth20@100ms"
            for ticker in tickers
        ])
        url = f"wss://fstream.binance.com/stream?streams={streams}"
        logger.info(f"Подключение к FUTURES WebSocket: {url}")

        websocket = await self.connect(url)
        try:
            async for message in websocket:
                data = json.loads(message)
                stream = data.get('stream', '')
                payload = data.get('data', {})

                ticker = stream.split('@')[0].upper()

                if '@kline' in stream:
                    kline = payload.get('k', {})
                    result = {
                        "ticker": ticker,
                        "open": float(kline["o"]),
                        "close": float(kline["c"]),
                        "high": float(kline["h"]),
                        "low": float(kline["l"]),
                        "volume": float(kline["v"]),
                        "is_closed": kline["x"],
                        "time_start": kline["t"],
                        "time_close": kline["T"],
                        "is_futures": True,
                        "type": "kline"
                    }
                    await callback(result)

                elif '@depth' in stream:
                    result = {
                        "ticker": ticker,
                        "bids": payload.get("b", []),
                        "asks": payload.get("a", []),
                        "is_futures": True,
                        "type": "depth"
                    }
                    await callback(result)

        except websockets.ConnectionClosed:
            logger.warning("Соединение FUTURES WebSocket закрыто. Переподключение...")


    async def connect(self, url):
        while self.running:
            try:
                websocket = await websockets.connect(url)
                logger.info(f"Успешное подключение к {url}")
                return websocket
            except Exception as e:
                logger.error(f"Ошибка подключения к {url}: {e}. Повтор через 5 секунд.")
                await asyncio.sleep(5)
        return None

import asyncio
from loguru import logger
from bot_manager import BotManager  # Импортируем BotManager из отдельного файла

async def main():
    logger.add("logs/trading_bot.log", rotation="1 MB", level="INFO")
    bot = BotManager()

    await bot.start()
    await asyncio.Event().wait()

if __name__ == "__main__":
    asyncio.run(main())

import json
import os
from loguru import logger

TRACKING_TICKERS = ["btcusdt", "solusdt", "ethusdt"]

def get_ticker_settings(ticker, custom=False):

    # Загружаем базовые настройки
    if not os.path.exists("default_settings.json"):
        logger.error("Файл базовых настроек default_settings.json не найден!")
        return {}

    with open("default_settings.json", 'r') as f:
        default_settings = json.load(f)

    # Проверяем, есть ли настройки для тикера
    if ticker not in default_settings:
        logger.warning(f"Базовые настройки для {ticker} не найдены, используются значения по умолчанию")
        default_settings[ticker] = {
            "rsi_period": 14,
            "rsi_overbought": 70,
            "rsi_oversold": 30,
            "max_leverage": 10,
            "allow_long": True,
            "allow_short": True
        }
        with open("default_settings.json", 'w') as f:
            json.dump(default_settings, f, indent=2)

    settings = default_settings[ticker].copy()

    # Если нужны кастомные настройки
    if custom:
        if os.path.exists("custom_settings.json"):
            with open("custom_settings.json", 'r') as f:
                custom_settings = json.load(f)
            if ticker in custom_settings:
                settings.update(custom_settings[ticker])
        else:
            logger.info("Файл custom_settings.json не найден, используются базовые настройки")

    return settings


def update_custom_settings(ticker, new_settings):
    """
    Сохраняет изменения в кастомные настройки для тикера.
    """
    custom_settings = {}
    if os.path.exists("custom_settings.json"):
        with open("custom_settings.json", 'r') as f:
            custom_settings = json.load(f)

    custom_settings[ticker] = custom_settings.get(ticker, {})
    custom_settings[ticker].update(new_settings)

    with open("custom_settings.json", 'w') as f:
        json.dump(custom_settings, f, indent=2)
    logger.info(f"Кастомные настройки для {ticker} обновлены: {new_settings}")
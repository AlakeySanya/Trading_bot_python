from loguru import logger
from core.websocket_handler import WebSocketHandler
from core.trading_strategy import TradingStrategy
from core.ticker_settings_manager import TRACKING_TICKERS

class BotManager:
    def __init__(self):
        self.websocket = WebSocketHandler()
        self.strategy = TradingStrategy()
        logger.info("BotManager инициализирован")

    async def start(self):
        await self.websocket.start(TRACKING_TICKERS, TRACKING_TICKERS, self.handle_data)

    async def stop(self):
        await self.websocket.stop()
        logger.info("BotManager остановлен")

    async def handle_data(self, data):
        logger.info(f"Обработка свечи: {data}")
